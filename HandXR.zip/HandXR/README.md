# HandXR – iPhone 12, kamera + śledzenie dłoni + menu AR (styl Quest)

Telefon trzymaj/załóż w poziomie (landscape). Menu wisi w przestrzeni przed Tobą (ARKit world tracking).
Dłoń: Vision. Ściśnij kciuk z palcem wskazującym (pinch) nad przyciskiem = klik.

## Opcja A – masz Maca
brew install xcodegen
xcodegen generate
open HandXR.xcodeproj  -> wybierz swój Team w Signing -> Run na iPhonie

## Opcja B – bez Maca
1. Wrzuć ten folder na GitHub (repo).
2. Zakładka Actions -> "Build IPA" -> pobierz artefakt HandXR.ipa.
3. Podpisz i zainstaluj przez Sideloadly / AltStore (darmowe Apple ID, ważne 7 dni).
