import SwiftUI

@main
struct HandXRApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
