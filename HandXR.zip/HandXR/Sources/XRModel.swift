import SwiftUI
import ARKit
import Vision
import CoreImage

typealias Joint = VNHumanHandPoseObservation.JointName

final class XRModel: NSObject, ObservableObject, ARSessionDelegate {
    let session = ARSession()
    private let ciContext = CIContext()
    private let queue = DispatchQueue(label: "xr.frames")
    private var busy = false
    private let handRequest: VNDetectHumanHandPoseRequest = {
        let r = VNDetectHumanHandPoseRequest()
        r.maximumHandCount = 1
        return r
    }()

    // Stan UI
    @Published var image: CGImage?
    @Published var hand: [Joint: CGPoint] = [:]   // współrzędne znormalizowane Vision (0..1, początek lewy-dół)
    @Published var pinching = false
    @Published var showSkeleton = true
    @Published var stereo = false
    @Published var colorIndex = 0
    @Published var hover: Int?
    @Published var cursor: CGPoint?

    var cam: ARCamera?
    var imageAspect: CGFloat = 4.0 / 3.0
    var viewport = CGSize(width: 844, height: 390)

    // Menu zakotwiczone w świecie
    var menuC: simd_float3?
    var menuR = simd_float3(1, 0, 0)
    var menuU = simd_float3(0, 1, 0)

    private let palette: [Color] = [.blue, .purple, .green, .orange]
    private var labels: [String] {
        ["Szkielet dłoni: \(showSkeleton ? "ON" : "OFF")",
         "Tryb VR (2 oczy): \(stereo ? "ON" : "OFF")",
         "Przesuń menu tutaj",
         "Zmień kolor menu"]
    }

    // MARK: - Start

    func start() {
        session.delegate = self
        session.delegateQueue = queue
        session.run(ARWorldTrackingConfiguration())
        UIApplication.shared.isIdleTimerDisabled = true
    }

    // MARK: - ARSessionDelegate (wątek tła)

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard !busy else { return }
        busy = true

        let pb = frame.capturedImage
        let camera = frame.camera
        let aspect = CGFloat(CVPixelBufferGetWidth(pb)) / CGFloat(CVPixelBufferGetHeight(pb))

        let ci = CIImage(cvPixelBuffer: pb)
        let cg = ciContext.createCGImage(ci, from: ci.extent)

        // Telefon w poziomie (landscapeRight) => obraz z kamery jest w orientacji .up
        let handler = VNImageRequestHandler(cvPixelBuffer: pb, orientation: .up, options: [:])
        var joints: [Joint: CGPoint] = [:]
        var ratio: CGFloat?
        if (try? handler.perform([handRequest])) != nil,
           let obs = handRequest.results?.first,
           let all = try? obs.recognizedPoints(.all) {
            for (k, v) in all where v.confidence > 0.3 {
                joints[k] = CGPoint(x: v.location.x, y: v.location.y)
            }
            if let t = joints[.thumbTip], let i = joints[.indexTip],
               let w = joints[.wrist], let m = joints[.middleMCP] {
                let d = hypot((i.x - t.x) * aspect, i.y - t.y)
                let palm = hypot((w.x - m.x) * aspect, w.y - m.y)
                if palm > 0.001 { ratio = d / palm }
            }
        }

        DispatchQueue.main.async {
            self.apply(cg: cg, camera: camera, aspect: aspect, joints: joints, ratio: ratio)
            self.busy = false
        }
    }

    // MARK: - Logika (wątek główny)

    private func apply(cg: CGImage?, camera: ARCamera, aspect: CGFloat,
                       joints: [Joint: CGPoint], ratio: CGFloat?) {
        cam = camera
        imageAspect = aspect
        if menuC == nil, case .normal = camera.trackingState { placeMenu() }

        let was = pinching
        if let r = ratio {
            if pinching { if r > 0.5 { pinching = false } }
            else if r < 0.25 { pinching = true }
        } else {
            pinching = false
        }

        if let t = joints[.thumbTip], let i = joints[.indexTip] {
            let mid = CGPoint(x: (t.x + i.x) / 2, y: (t.y + i.y) / 2)
            cursor = fill(mid, in: viewport)
        } else {
            cursor = nil
        }

        let rects = menuRects(size: viewport, eye: 0)
        if let c = cursor {
            hover = rects.firstIndex { $0.insetBy(dx: -8, dy: -8).contains(c) }
        } else {
            hover = nil
        }
        if pinching && !was, let h = hover { activate(h) }

        hand = joints
        image = cg
    }

    private func activate(_ i: Int) {
        switch i {
        case 0: showSkeleton.toggle()
        case 1: stereo.toggle()
        case 2: placeMenu()
        case 3: colorIndex = (colorIndex + 1) % palette.count
        default: break
        }
    }

    private func placeMenu() {
        guard let cam else { return }
        let t = cam.transform
        let pos = simd_float3(t.columns.3.x, t.columns.3.y, t.columns.3.z)
        var f = -simd_float3(t.columns.2.x, t.columns.2.y, t.columns.2.z)
        f.y = 0
        if simd_length(f) < 0.01 { f = simd_float3(0, 0, -1) }
        f = simd_normalize(f)
        menuC = pos + f * 0.7
        menuR = simd_normalize(simd_cross(f, simd_float3(0, 1, 0)))
        menuU = simd_float3(0, 1, 0)
    }

    // MARK: - Geometria

    /// Mapowanie punktu Vision (0..1, lewy-dół) na ekran z "aspect fill".
    private func fill(_ p: CGPoint, in size: CGSize) -> CGPoint {
        var sw = size.width, sh = size.height
        if size.width / size.height > imageAspect { sh = size.width / imageAspect }
        else { sw = size.height * imageAspect }
        let ox = (size.width - sw) / 2, oy = (size.height - sh) / 2
        return CGPoint(x: ox + p.x * sw, y: oy + (1 - p.y) * sh)
    }

    /// Rzutowanie punktu świata na ekran dla danego oka (-1 lewe, 0 środek, 1 prawe).
    private func project(_ p: simd_float3, size: CGSize, eye: Int) -> CGPoint? {
        guard let cam else { return nil }
        let t = cam.transform
        let pos = simd_float3(t.columns.3.x, t.columns.3.y, t.columns.3.z)
        let right = simd_float3(t.columns.0.x, t.columns.0.y, t.columns.0.z)
        let fwd = -simd_float3(t.columns.2.x, t.columns.2.y, t.columns.2.z)
        if simd_dot(p - pos, fwd) < 0.15 { return nil }          // za kamerą / zbyt blisko
        let q = p - right * Float(eye) * 0.032                    // IPD ~ 64 mm
        return cam.projectPoint(q, orientation: .landscapeRight, viewportSize: size)
    }

    func menuRects(size: CGSize, eye: Int) -> [CGRect] {
        guard let c = menuC else { return [] }
        let n = labels.count
        var out: [CGRect] = []
        for i in 0..<n {
            let y = (Float(n - 1) / 2 - Float(i)) * 0.075
            let center = c + menuU * y
            guard let s0 = project(center, size: size, eye: eye),
                  let s1 = project(center + menuR * 0.1, size: size, eye: eye) else { return [] }
            let k = abs(s1.x - s0.x) / 0.1          // piksele na metr
            out.append(CGRect(x: s0.x - 0.11 * k, y: s0.y - 0.03 * k, width: 0.22 * k, height: 0.06 * k))
        }
        return out
    }

    // MARK: - Rysowanie

    private let chains: [[Joint]] = [
        [.wrist, .thumbCMC, .thumbMP, .thumbIP, .thumbTip],
        [.wrist, .indexMCP, .indexPIP, .indexDIP, .indexTip],
        [.wrist, .middleMCP, .middlePIP, .middleDIP, .middleTip],
        [.wrist, .ringMCP, .ringPIP, .ringDIP, .ringTip],
        [.wrist, .littleMCP, .littlePIP, .littleDIP, .littleTip]
    ]

    func draw(_ ctx: inout GraphicsContext, size: CGSize, eye: Int) {
        // Menu
        let rects = menuRects(size: size, eye: eye)
        let lbl = labels
        for (i, r) in rects.enumerated() {
            let hov = hover == i
            let path = Path(roundedRect: r, cornerRadius: r.height * 0.3)
            ctx.fill(path, with: .color(palette[colorIndex].opacity(hov ? 0.95 : 0.6)))
            ctx.stroke(path, with: .color(.white.opacity(hov ? 1 : 0.5)), lineWidth: hov ? 3 : 1.5)
            ctx.draw(Text(lbl[i])
                        .font(.system(size: max(9, r.height * 0.36), weight: .semibold))
                        .foregroundColor(.white),
                     at: CGPoint(x: r.midX, y: r.midY))
        }

        // Szkielet dłoni
        if showSkeleton {
            for chain in chains {
                let pts = chain.compactMap { hand[$0] }.map { fill($0, in: size) }
                guard pts.count > 1 else { continue }
                var p = Path()
                p.move(to: pts[0])
                for q in pts.dropFirst() { p.addLine(to: q) }
                ctx.stroke(p, with: .color(.green.opacity(0.9)), lineWidth: 3)
            }
            for (_, v) in hand {
                let q = fill(v, in: size)
                ctx.fill(Path(ellipseIn: CGRect(x: q.x - 4, y: q.y - 4, width: 8, height: 8)),
                         with: .color(.white))
            }
        }

        // Kursor (środek między kciukiem a palcem wskazującym)
        if let c = cursor {
            let r: CGFloat = pinching ? 10 : 16
            let circle = Path(ellipseIn: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r))
            if pinching { ctx.fill(circle, with: .color(.yellow)) }
            ctx.stroke(circle, with: .color(.yellow), lineWidth: 3)
        }
    }
}
