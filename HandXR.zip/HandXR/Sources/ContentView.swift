import SwiftUI

struct ContentView: View {
    @StateObject private var model = XRModel()

    var body: some View {
        ZStack {
            Color.black
            if model.stereo {
                HStack(spacing: 0) {
                    EyeView(model: model, eye: -1)
                    EyeView(model: model, eye: 1)
                }
            } else {
                EyeView(model: model, eye: 0)
            }
        }
        .ignoresSafeArea()
        .statusBarHidden(true)
        .onAppear { model.start() }
    }
}

struct EyeView: View {
    @ObservedObject var model: XRModel
    let eye: Int

    var body: some View {
        GeometryReader { g in
            ZStack {
                CameraLayer(image: model.image)
                Canvas { ctx, size in
                    model.draw(&ctx, size: size, eye: eye)
                }
            }
            .onAppear { model.viewport = g.size }
            .onChange(of: g.size) { model.viewport = $0 }
        }
        .clipped()
    }
}

/// Wyświetla klatkę z kamery (aspect fill).
struct CameraLayer: UIViewRepresentable {
    let image: CGImage?

    func makeUIView(context: Context) -> UIView {
        let v = UIView()
        v.backgroundColor = .black
        v.layer.contentsGravity = .resizeAspectFill
        v.layer.masksToBounds = true
        return v
    }

    func updateUIView(_ v: UIView, context: Context) {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        v.layer.contents = image
        CATransaction.commit()
    }
}
